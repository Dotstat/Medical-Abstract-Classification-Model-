#!/usr/bin/env python
from fusionlab.cli import cmd_train
if __name__ == "__main__":
    cmd_train()
